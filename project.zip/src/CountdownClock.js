function CountdownClock() {
      const [time, setTime] = useState(10);
      const [intervalId, setIntervalId] = useState(null);
      const [cycle, setCycle] = useState(1);

      useEffect(() => {
        const intervalId = setInterval(() => {
          if (time > 0) {
            setTime(time - 1);
          } else {
            setCycle(cycle => cycle === 1 ? 2 : 1);
            setTime(cycle === 1 ? 10 : 30);
          }
        }, 1000);

        return () => clearInterval(intervalId);
      }, [time, cycle]);

      const handleStop = () => {
        clearInterval(intervalId);
      };

      return (
        <div className="flex justify-center items-center h-screen">
          <div className="bg-gray-800 text-white p-4 rounded-lg shadow-md">
            <h2 className="text-2xl font-bold mb-4">Countdown Clock</h2>
            <p className="text-6xl font-bold mb-4">{time}</p>
            <button className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded" onClick={handleStop}>Stop</button>
          </div>
        </div>
      );
    }

    export default CountdownClock;

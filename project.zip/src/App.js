import React from 'react';
    import CountdownClock from './CountdownClock';

    function App() {
      return (
        <div className="h-screen">
          <CountdownClock />
        </div>
      );
    }

    export default App;
